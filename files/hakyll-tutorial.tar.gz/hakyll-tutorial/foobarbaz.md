Foo, bar and baz!
===

Look at our deep and innate understanding of hacker culture.  Almost
an entire afternoon was spent perusing the Hacker's Dictionary.
