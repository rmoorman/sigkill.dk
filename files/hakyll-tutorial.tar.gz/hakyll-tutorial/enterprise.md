Enterprise-ready
===

Yes, we have XML!